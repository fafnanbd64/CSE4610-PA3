import java.util.ArrayList;

public class InformationElement implements ArgumentElement {
    
    

    @Override
    public String accept(Print_Visitor visitor) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ArrayList<AssertedRelationship> getRelations() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getId() {
        // TODO Auto-generated method stub
        return null;
    }

    
    
}
