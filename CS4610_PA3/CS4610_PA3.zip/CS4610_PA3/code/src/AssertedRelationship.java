
public interface AssertedRelationship extends ArgumentElement{

    public ArgumentElement getChild();
    public ArgumentElement getParent();
    

 
    
}
